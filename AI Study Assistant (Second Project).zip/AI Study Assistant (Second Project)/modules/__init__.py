"""Core modules for the AI Study Assistant terminal app."""
